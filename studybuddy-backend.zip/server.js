// ============================================================
//  Study Buddy - Backend Server
//  Stack: Node.js + Express | Storage: JSON files (no DB needed)
//  Run:   npm install && node server.js
//  Port:  5500  (same port your frontend uses)
// ============================================================

const express = require('express');
const multer  = require('multer');
const cors    = require('cors');
const path    = require('path');
const fs      = require('fs');
const { v4: uuidv4 } = require('uuid');

const app  = express();
const PORT = 5500;

// ── Middleware ───────────────────────────────────────────────
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Serve your HTML frontend files from the same folder
// Put all your .html files next to server.js OR adjust this path:
app.use(express.static(path.join(__dirname, 'public')));

// Serve uploaded notes files
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// ── Simple JSON "Database" helpers ──────────────────────────
const DB_DIR = path.join(__dirname, 'data');
if (!fs.existsSync(DB_DIR)) fs.mkdirSync(DB_DIR);

function readDB(name) {
  const file = path.join(DB_DIR, `${name}.json`);
  if (!fs.existsSync(file)) return [];
  return JSON.parse(fs.readFileSync(file, 'utf8'));
}

function writeDB(name, data) {
  const file = path.join(DB_DIR, `${name}.json`);
  fs.writeFileSync(file, JSON.stringify(data, null, 2));
}

// Seed default data if empty
function seedIfEmpty(name, defaultData) {
  if (readDB(name).length === 0) writeDB(name, defaultData);
}

seedIfEmpty('profile', [{
  id: 'student-1',
  name: 'Student Name',
  course: 'BCA',
  semester: 'Semester IV',
  email: 'student@email.com',
  avatar: null,
  points: 350
}]);

seedIfEmpty('ranking', [
  { rank: 1, name: 'Amit Kumar',  points: 420 },
  { rank: 2, name: 'Sneha Patel', points: 395 },
  { rank: 3, name: 'Rahul Das',   points: 370 },
  { rank: 4, name: 'You',         points: 350, isCurrentUser: true }
]);

seedIfEmpty('progress', [
  { subject: 'DBMS',                percent: 75 },
  { subject: 'Computer Networks',   percent: 60 },
  { subject: 'Software Engineering',percent: 85 }
]);

seedIfEmpty('students', [
  { id: 'rahul', name: 'Rahul',  course: 'BCA', avatar: null },
  { id: 'anita', name: 'Anita',  course: 'BCA', avatar: null },
  { id: 'amit',  name: 'Amit',   course: 'BCA', avatar: null }
]);

seedIfEmpty('messages', [
  { id: uuidv4(), from: 'me',    to: 'anita', text: 'Hi! Have you completed DBMS notes?',  time: '12:20' },
  { id: uuidv4(), from: 'anita', to: 'me',    text: 'Yes, I finished Unit-3 today 😊',       time: '12:21' }
]);

// ── Multer for file uploads ──────────────────────────────────
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, path.join(__dirname, 'uploads')),
  filename:    (req, file, cb) => cb(null, Date.now() + '-' + file.originalname)
});
const upload = multer({ storage, limits: { fileSize: 20 * 1024 * 1024 } }); // 20 MB


// ════════════════════════════════════════════════════════════
//  ROUTES
// ════════════════════════════════════════════════════════════

// ── Dashboard ────────────────────────────────────────────────
// GET /api/dashboard  → profile + ranking + progress
app.get('/api/dashboard', (req, res) => {
  const profile  = readDB('profile')[0] || {};
  const ranking  = readDB('ranking');
  const progress = readDB('progress');
  res.json({ profile, ranking, progress });
});


// ── Profile ──────────────────────────────────────────────────
// GET  /api/profile
app.get('/api/profile', (req, res) => {
  const profile = readDB('profile')[0] || {};
  res.json(profile);
});

// PUT  /api/profile  — update name / course / semester / email
app.put('/api/profile', (req, res) => {
  const profiles = readDB('profile');
  if (profiles.length === 0) return res.status(404).json({ error: 'Profile not found' });

  const { name, course, semester, email } = req.body;
  if (name)     profiles[0].name     = name;
  if (course)   profiles[0].course   = course;
  if (semester) profiles[0].semester = semester;
  if (email)    profiles[0].email    = email;

  writeDB('profile', profiles);
  res.json({ success: true, profile: profiles[0] });
});


// ── Notes ────────────────────────────────────────────────────
// GET  /api/notes          → list all notes for current user
app.get('/api/notes', (req, res) => {
  const notes = readDB('notes');
  res.json(notes);
});

// POST /api/notes          → upload a note file
app.post('/api/notes', upload.single('file'), (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'No file uploaded' });
  const { subject } = req.body;
  if (!subject)    return res.status(400).json({ error: 'Subject name is required' });

  const notes = readDB('notes');
  const note  = {
    id:          uuidv4(),
    subject,
    fileName:    req.file.originalname,
    storedName:  req.file.filename,
    uploadedAt:  new Date().toISOString(),
    downloadUrl: `/uploads/${req.file.filename}`
  };
  notes.push(note);
  writeDB('notes', notes);
  res.json({ success: true, note });
});

// DELETE /api/notes/:id    → delete a note
app.delete('/api/notes/:id', (req, res) => {
  let notes = readDB('notes');
  const note = notes.find(n => n.id === req.params.id);
  if (!note) return res.status(404).json({ error: 'Note not found' });

  // Remove file from disk
  const filePath = path.join(__dirname, 'uploads', note.storedName);
  if (fs.existsSync(filePath)) fs.unlinkSync(filePath);

  notes = notes.filter(n => n.id !== req.params.id);
  writeDB('notes', notes);
  res.json({ success: true });
});


// ── Planner ──────────────────────────────────────────────────
// GET  /api/planner        → list all tasks
app.get('/api/planner', (req, res) => {
  const tasks = readDB('planner');
  res.json(tasks);
});

// POST /api/planner        → add task  { task, dueDate }
app.post('/api/planner', (req, res) => {
  const { task, dueDate } = req.body;
  if (!task || !dueDate) return res.status(400).json({ error: 'task and dueDate are required' });

  const tasks  = readDB('planner');
  const newTask = { id: uuidv4(), task, dueDate, completed: false, createdAt: new Date().toISOString() };
  tasks.push(newTask);
  writeDB('planner', tasks);
  res.json({ success: true, task: newTask });
});

// PATCH /api/planner/:id   → toggle completed
app.patch('/api/planner/:id', (req, res) => {
  const tasks = readDB('planner');
  const t     = tasks.find(t => t.id === req.params.id);
  if (!t) return res.status(404).json({ error: 'Task not found' });

  t.completed = !t.completed;
  writeDB('planner', tasks);
  res.json({ success: true, task: t });
});

// DELETE /api/planner/:id  → delete task
app.delete('/api/planner/:id', (req, res) => {
  let tasks = readDB('planner');
  tasks     = tasks.filter(t => t.id !== req.params.id);
  writeDB('planner', tasks);
  res.json({ success: true });
});


// ── Reminders ────────────────────────────────────────────────
// GET  /api/reminders
app.get('/api/reminders', (req, res) => {
  res.json(readDB('reminders'));
});

// POST /api/reminders   { title, date, time }
app.post('/api/reminders', (req, res) => {
  const { title, date, time } = req.body;
  if (!title || !date || !time) return res.status(400).json({ error: 'title, date and time are required' });

  const reminders = readDB('reminders');
  const reminder  = { id: uuidv4(), title, date, time, createdAt: new Date().toISOString() };
  reminders.push(reminder);
  writeDB('reminders', reminders);
  res.json({ success: true, reminder });
});

// DELETE /api/reminders/:id
app.delete('/api/reminders/:id', (req, res) => {
  let reminders = readDB('reminders');
  reminders     = reminders.filter(r => r.id !== req.params.id);
  writeDB('reminders', reminders);
  res.json({ success: true });
});


// ── Student Connect (Chat) ───────────────────────────────────
// GET  /api/students                → list all students
app.get('/api/students', (req, res) => {
  res.json(readDB('students'));
});

// GET  /api/messages/:studentId     → chat history with a student
app.get('/api/messages/:studentId', (req, res) => {
  const all = readDB('messages');
  const sid = req.params.studentId;
  const thread = all.filter(
    m => (m.from === 'me' && m.to === sid) || (m.from === sid && m.to === 'me')
  );
  res.json(thread);
});

// POST /api/messages/:studentId     → send message { text }
app.post('/api/messages/:studentId', (req, res) => {
  const { text } = req.body;
  if (!text) return res.status(400).json({ error: 'text is required' });

  const messages = readDB('messages');
  const now      = new Date();
  const msg      = {
    id:   uuidv4(),
    from: 'me',
    to:   req.params.studentId,
    text,
    time: now.toTimeString().slice(0, 5)
  };
  messages.push(msg);
  writeDB('messages', messages);
  res.json({ success: true, message: msg });
});


// ── Ranking & Progress ───────────────────────────────────────
// GET /api/ranking
app.get('/api/ranking', (req, res) => res.json(readDB('ranking')));

// GET /api/progress
app.get('/api/progress', (req, res) => res.json(readDB('progress')));

// PUT /api/progress/:subject  { percent }
app.put('/api/progress/:subject', (req, res) => {
  const progress = readDB('progress');
  const item     = progress.find(p => p.subject.toLowerCase() === req.params.subject.toLowerCase());
  if (!item) return res.status(404).json({ error: 'Subject not found' });

  item.percent = Math.min(100, Math.max(0, Number(req.body.percent)));
  writeDB('progress', progress);
  res.json({ success: true, item });
});


// ── Catch-all → serve index/dashboard ───────────────────────
app.get('*', (req, res) => {
  const indexFile = path.join(__dirname, 'public', 'dashboard.html');
  if (fs.existsSync(indexFile)) {
    res.sendFile(indexFile);
  } else {
    res.json({ message: 'Study Buddy API is running! Place your HTML files in /public folder.' });
  }
});


// ── Start ────────────────────────────────────────────────────
app.listen(PORT, () => {
  console.log(`\n✅  Study Buddy server running at http://127.0.0.1:${PORT}`);
  console.log(`📁  Place your HTML files inside the "public/" folder`);
  console.log(`📂  Uploaded files stored in "uploads/" folder`);
  console.log(`\nAPI Endpoints:`);
  console.log(`  GET/PUT   /api/profile`);
  console.log(`  GET       /api/dashboard`);
  console.log(`  GET/POST/DELETE /api/notes`);
  console.log(`  GET/POST/PATCH/DELETE /api/planner`);
  console.log(`  GET/POST/DELETE /api/reminders`);
  console.log(`  GET       /api/students`);
  console.log(`  GET/POST  /api/messages/:studentId`);
  console.log(`  GET       /api/ranking`);
  console.log(`  GET/PUT   /api/progress\n`);
});
