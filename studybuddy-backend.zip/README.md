# Study Buddy — Backend Setup Guide

## 📁 Folder Structure
```
studybuddy-backend/
│
├── server.js          ← Main backend server (run this)
├── package.json       ← Dependencies
│
├── public/            ← PUT ALL YOUR HTML FILES HERE
│   ├── api.js         ← Frontend helper (include in every HTML page)
│   ├── dashboard.html
│   ├── notes.html
│   ├── planner.html
│   ├── reminder.html
│   ├── studentconnect.html
│   └── profile.html
│
├── uploads/           ← Auto-created. Stores uploaded note files
└── data/              ← Auto-created. JSON files act as database
    ├── profile.json
    ├── notes.json
    ├── planner.json
    ├── reminders.json
    ├── messages.json
    ├── students.json
    ├── ranking.json
    └── progress.json
```

---

## 🚀 How to Run

### Step 1 — Install Node.js
Download from https://nodejs.org (choose LTS version)

### Step 2 — Install dependencies
Open terminal in the `studybuddy-backend` folder:
```bash
npm install
```

### Step 3 — Add your HTML files
Copy all your `.html` files into the `public/` folder.

### Step 4 — Start the server
```bash
node server.js
```

### Step 5 — Open in browser
Go to: http://127.0.0.1:5500/dashboard.html

---

## 🔌 Connect Your HTML Pages to the Backend

Add this ONE line to the `<head>` of every HTML file:
```html
<script src="api.js"></script>
```

Then update your HTML element IDs and button onclick handlers to match:

---

## 📋 Required HTML Element IDs

### dashboard.html
```html
<span id="welcome-name"></span>
<span id="welcome-info"></span>
<div id="ranking-list"></div>
<div id="progress-list"></div>

<script>loadDashboard();</script>
```

### planner.html
```html
<input id="task-input" placeholder="Enter task (e.g. DBMS Revision)">
<input id="task-date" type="date">
<button onclick="addTask()">Add Task</button>
<div id="task-list"></div>

<script>loadPlanner();</script>
```

### reminder.html
```html
<input id="reminder-title" placeholder="Reminder title">
<input id="reminder-date" type="date">
<input id="reminder-time" type="time">
<button onclick="addReminder()">Add Reminder</button>
<div id="reminder-list"></div>

<script>loadReminders();</script>
```

### notes.html
```html
<input id="note-subject" placeholder="Subject Name">
<input id="note-file" type="file">
<button onclick="uploadNote()">Upload</button>
<tbody id="notes-table-body"></tbody>

<script>loadNotes();</script>
```

### studentconnect.html
```html
<div id="student-list"></div>
<div id="chat-header"></div>
<div id="chat-messages"></div>
<input id="chat-input" placeholder="Type your message">
<button onclick="sendMessage()">Send</button>

<script>loadStudents();</script>
```

### profile.html
```html
<span id="profile-name"></span>
<span id="profile-course"></span>
<span id="profile-email"></span>

<!-- Edit form fields -->
<input id="input-name">
<input id="input-course">
<input id="input-semester">
<input id="input-email">
<button onclick="saveProfile()">Save</button>

<script>loadProfile();</script>
```

---

## 🌐 Full API Reference

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | /api/dashboard | Profile + ranking + progress |
| GET | /api/profile | Get profile |
| PUT | /api/profile | Update profile |
| GET | /api/notes | List notes |
| POST | /api/notes | Upload note (multipart) |
| DELETE | /api/notes/:id | Delete note |
| GET | /api/planner | List tasks |
| POST | /api/planner | Add task |
| PATCH | /api/planner/:id | Toggle complete |
| DELETE | /api/planner/:id | Delete task |
| GET | /api/reminders | List reminders |
| POST | /api/reminders | Add reminder |
| DELETE | /api/reminders/:id | Delete reminder |
| GET | /api/students | List students |
| GET | /api/messages/:studentId | Get chat messages |
| POST | /api/messages/:studentId | Send message |
| GET | /api/ranking | Weekly ranking |
| GET | /api/progress | Study progress |
| PUT | /api/progress/:subject | Update progress % |

---

## ❓ Troubleshooting

- **Port in use?** Change `PORT = 5500` in server.js to another number like 3000
- **CORS error?** Make sure `server.js` is running before opening HTML pages
- **File upload fails?** Check the `uploads/` folder exists (it's auto-created)
