// ============================================================
//  api.js  —  Frontend helper for Study Buddy backend
//  Include this script in ALL your HTML pages:
//  <script src="api.js"></script>
// ============================================================

const API = 'http://127.0.0.1:5500/api';

// ── Dashboard ────────────────────────────────────────────────
async function loadDashboard() {
  const res  = await fetch(`${API}/dashboard`);
  const data = await res.json();

  // Profile welcome
  const profile = data.profile;
  const nameEl  = document.getElementById('welcome-name');
  const infoEl  = document.getElementById('welcome-info');
  if (nameEl) nameEl.textContent = 'Welcome, ' + profile.name + ' 🔥';
  if (infoEl) infoEl.textContent = profile.course + ' | ' + profile.semester;

  // Weekly ranking
  const rankList = document.getElementById('ranking-list');
  if (rankList) {
    rankList.innerHTML = '';
    data.ranking.forEach(r => {
      const row = document.createElement('div');
      row.className = 'rank-row' + (r.isCurrentUser ? ' current-user' : '');
      row.innerHTML = `<span class="rank-num">${r.rank}</span>
                       <span class="rank-name">${r.name}</span>
                       <span class="rank-pts">${r.points} pts</span>`;
      rankList.appendChild(row);
    });
  }

  // Study progress bars
  const progEl = document.getElementById('progress-list');
  if (progEl) {
    progEl.innerHTML = '';
    data.progress.forEach(p => {
      progEl.innerHTML += `
        <div class="prog-item">
          <span>${p.subject}</span>
          <div class="prog-bar-bg">
            <div class="prog-bar" style="width:${p.percent}%"></div>
          </div>
        </div>`;
    });
  }
}

// ── Profile ──────────────────────────────────────────────────
async function loadProfile() {
  const res  = await fetch(`${API}/profile`);
  const data = await res.json();

  const setVal = (id, val) => { const el = document.getElementById(id); if (el) el.textContent = val; };
  const setInp = (id, val) => { const el = document.getElementById(id); if (el) el.value = val; };

  setVal('profile-name',     data.name);
  setVal('profile-course',   data.course + ' | ' + data.semester);
  setVal('profile-email',    'Email: ' + data.email);
  setInp('input-name',       data.name);
  setInp('input-course',     data.course);
  setInp('input-semester',   data.semester);
  setInp('input-email',      data.email);
}

async function saveProfile() {
  const body = {
    name:     document.getElementById('input-name')?.value,
    course:   document.getElementById('input-course')?.value,
    semester: document.getElementById('input-semester')?.value,
    email:    document.getElementById('input-email')?.value
  };
  const res  = await fetch(`${API}/profile`, { method: 'PUT', headers: {'Content-Type':'application/json'}, body: JSON.stringify(body) });
  const data = await res.json();
  if (data.success) { alert('Profile updated!'); loadProfile(); }
}

// ── Notes ────────────────────────────────────────────────────
async function loadNotes() {
  const res   = await fetch(`${API}/notes`);
  const notes = await res.json();
  const tbody = document.getElementById('notes-table-body');
  if (!tbody) return;
  tbody.innerHTML = '';
  notes.forEach(n => {
    tbody.innerHTML += `
      <tr>
        <td>${n.subject}</td>
        <td>${n.fileName}</td>
        <td>
          <a href="${n.downloadUrl}" download>
            <button class="btn-blue">Download</button>
          </a>
          <button class="btn-red" onclick="deleteNote('${n.id}')">Delete</button>
        </td>
      </tr>`;
  });
}

async function uploadNote() {
  const subject  = document.getElementById('note-subject')?.value?.trim();
  const fileInp  = document.getElementById('note-file');
  if (!subject || !fileInp?.files[0]) return alert('Please enter subject and choose a file.');

  const formData = new FormData();
  formData.append('subject', subject);
  formData.append('file', fileInp.files[0]);

  const res  = await fetch(`${API}/notes`, { method: 'POST', body: formData });
  const data = await res.json();
  if (data.success) { alert('Note uploaded!'); document.getElementById('note-subject').value = ''; fileInp.value = ''; loadNotes(); }
  else alert(data.error);
}

async function deleteNote(id) {
  if (!confirm('Delete this note?')) return;
  await fetch(`${API}/notes/${id}`, { method: 'DELETE' });
  loadNotes();
}

// ── Planner ──────────────────────────────────────────────────
async function loadPlanner() {
  const res   = await fetch(`${API}/planner`);
  const tasks = await res.json();
  const list  = document.getElementById('task-list');
  if (!list) return;
  list.innerHTML = '';
  if (tasks.length === 0) { list.innerHTML = '<p>No upcoming tasks.</p>'; return; }
  tasks.forEach(t => {
    list.innerHTML += `
      <div class="task-item ${t.completed ? 'done' : ''}">
        <span class="task-check" onclick="toggleTask('${t.id}')">
          ${t.completed ? '✅' : '⬜'}
        </span>
        <span class="task-name">${t.task}</span>
        <span class="task-date">${t.dueDate}</span>
        <button class="btn-red small" onclick="deleteTask('${t.id}')">✕</button>
      </div>`;
  });
}

async function addTask() {
  const task    = document.getElementById('task-input')?.value?.trim();
  const dueDate = document.getElementById('task-date')?.value;
  if (!task || !dueDate) return alert('Please enter task name and due date.');

  const res  = await fetch(`${API}/planner`, {
    method: 'POST',
    headers: {'Content-Type':'application/json'},
    body: JSON.stringify({ task, dueDate })
  });
  const data = await res.json();
  if (data.success) {
    document.getElementById('task-input').value = '';
    document.getElementById('task-date').value  = '';
    loadPlanner();
  }
}

async function toggleTask(id) {
  await fetch(`${API}/planner/${id}`, { method: 'PATCH' });
  loadPlanner();
}

async function deleteTask(id) {
  await fetch(`${API}/planner/${id}`, { method: 'DELETE' });
  loadPlanner();
}

// ── Reminders ────────────────────────────────────────────────
async function loadReminders() {
  const res       = await fetch(`${API}/reminders`);
  const reminders = await res.json();
  const list      = document.getElementById('reminder-list');
  if (!list) return;
  list.innerHTML = '';
  if (reminders.length === 0) { list.innerHTML = '<p>No reminders set.</p>'; return; }
  reminders.forEach(r => {
    list.innerHTML += `
      <div class="reminder-item">
        <strong>${r.title}</strong>
        <span>${r.date} at ${r.time}</span>
        <button class="btn-red small" onclick="deleteReminder('${r.id}')">✕</button>
      </div>`;
  });
}

async function addReminder() {
  const title = document.getElementById('reminder-title')?.value?.trim();
  const date  = document.getElementById('reminder-date')?.value;
  const time  = document.getElementById('reminder-time')?.value;
  if (!title || !date || !time) return alert('Please fill all reminder fields.');

  const res  = await fetch(`${API}/reminders`, {
    method: 'POST',
    headers: {'Content-Type':'application/json'},
    body: JSON.stringify({ title, date, time })
  });
  const data = await res.json();
  if (data.success) {
    document.getElementById('reminder-title').value = '';
    document.getElementById('reminder-date').value  = '';
    document.getElementById('reminder-time').value  = '';
    loadReminders();
  }
}

async function deleteReminder(id) {
  await fetch(`${API}/reminders/${id}`, { method: 'DELETE' });
  loadReminders();
}

// ── Student Connect ──────────────────────────────────────────
let currentStudent = null;

async function loadStudents() {
  const res      = await fetch(`${API}/students`);
  const students = await res.json();
  const list     = document.getElementById('student-list');
  if (!list) return;
  list.innerHTML = '';
  students.forEach(s => {
    const div = document.createElement('div');
    div.className   = 'student-item';
    div.innerHTML   = `<span class="avatar-icon">👤</span> ${s.name} (${s.course})`;
    div.onclick     = () => openChat(s);
    list.appendChild(div);
  });
}

async function openChat(student) {
  currentStudent = student;
  const header = document.getElementById('chat-header');
  if (header) header.textContent = student.name;

  const res      = await fetch(`${API}/messages/${student.id}`);
  const messages = await res.json();
  const chatBox  = document.getElementById('chat-messages');
  if (!chatBox) return;
  chatBox.innerHTML = '';
  messages.forEach(m => {
    const div = document.createElement('div');
    div.className = 'chat-msg ' + (m.from === 'me' ? 'msg-me' : 'msg-them');
    div.textContent = m.text;
    chatBox.appendChild(div);
  });
  chatBox.scrollTop = chatBox.scrollHeight;
}

async function sendMessage() {
  if (!currentStudent) return alert('Select a student first.');
  const input = document.getElementById('chat-input');
  const text  = input?.value?.trim();
  if (!text) return;

  await fetch(`${API}/messages/${currentStudent.id}`, {
    method: 'POST',
    headers: {'Content-Type':'application/json'},
    body: JSON.stringify({ text })
  });
  input.value = '';
  openChat(currentStudent);
}
